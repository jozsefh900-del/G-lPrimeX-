GÓLPRIMEX — statikus weboldal
============================

Ez egy egyszerű statikus weboldal minta a 'GÓLPRIMEX' számára. A csomag tartalmaz:

- index.html (kezdőlap)
- about.html (rólunk)
- contact.html (kapcsolat – egyszerű űrlappal)
- styles.css
- script.js
- logo-placeholder.svg

Telepítés:
1. Csomagold ki a zip fájlt a szerver gyökerébe vagy tetszőleges mappába.
2. Nyisd meg az index.html-t böngészőben, vagy töltsd fel a tárhelyedre.

Szükséged van testreszabásra? Írd meg milyen változtatásokat szeretnél (színek, logo, tartalom), és frissítem.
